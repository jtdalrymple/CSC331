package game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class Frame extends JFrame implements ActionListener, ItemListener {
	private static final long serialVersionUID = 2721843806653873180L;
	private JTextField timeDisplay;
	protected Clip music;

	// This is what he had previously
//	public Frame(Game game, int w, int h) {
//		setMaximumSize(new Dimension(w, h));
//		setMinimumSize(new Dimension(w, h));
//		setPreferredSize(new Dimension(w, h));
//        this.setBackground(Color.BLACK);
//        this.add(createMenuBar());
//		setVisible(true);
//	}

	public Frame(Game game, int w, int h) {
		super("Aim Trainer");
		setMaximumSize(new Dimension(w, h));
		setMinimumSize(new Dimension(w, h));
		setPreferredSize(new Dimension(w, h));
		setJMenuBar(createMenuBar());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		add(game);
		setVisible(true);
		timeDisplay = new JTextField(Integer.toString(0), 10);
		JPanel pSouth = new JPanel();
		pSouth.add(timeDisplay);
		add(pSouth, BorderLayout.SOUTH);
		setResizable(false);
		setVisible(true);
		game.start();

		music.setFramePosition(0);
		music.start();
	}

	public Clip getAudioClip(String filename) {
		Clip clip = null;
		try {
			clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(new File(filename)));
		} catch (LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
			e1.printStackTrace();
		}

		return clip;
	}

	public JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenuItem menuItem;
		JMenu levelMenu = new JMenu("Levels");
		String[] commandslevels = { "Level 1", "Level 2", "Level 3" };
		for (int i = 0; i < commandslevels.length; i++) {
			menuItem = new JMenuItem(commandslevels[i]);
			menuItem.addActionListener(this);
			levelMenu.add(menuItem);
		}
		menuBar.add(levelMenu);
		JMenu scoreMenu = new JMenu("Highscores");
		String[] commandsedit = { "Highscores 1", "Highscores 2", "Highscores 3" };
		for (int i = 0; i < commandsedit.length; i++) {
			menuItem = new JMenuItem(commandsedit[i]);
			menuItem.addActionListener(this);
			scoreMenu.add(menuItem);
		}
		menuBar.add(scoreMenu);
		this.music = getAudioClip("music.aiff");
		return menuBar;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub

	}

	public void setTime(int t) {
		timeDisplay.setText(Integer.toString(t));
	}
//public static void main(String[] args) {
//	try {
//		UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
//	} catch (Exception unused) {
//		;
//	}
//	new Frame(null, 1920, 1080);
//
//}

}
