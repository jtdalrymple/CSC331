package shapes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.util.ArrayList;

import shapes.Rectangle;
import game.Game;
import game.Handler;

public class Player extends Ellipse implements MoveableShape {

	private static final long serialVersionUID = -9086638501058842642L;
	private boolean changeColor;	
	private Color c1;
	private int x1;
	private int y1;
	private Handler handler;

	public Player(int x, int y, int w, int h, Color c, Handler handler) {
		super(x, y, w, h, c);
		this.c1 = c;
		this.x1 = x;
		this.y1 = y;
		this.handler = handler;
		changeColor = false;
	}

	public void tick() {
		
	}

	public void render(Graphics2D g2) {	
		Color nextColor = c1;
		if (changeColor == true) {
			if (c1.getRGB() == Color.RED.getRGB()) {
				nextColor = Color.BLUE;
				setColor(nextColor);
			}
			if (c1.getRGB() == Color.BLUE.getRGB()) {
				nextColor = Color.RED;
				setColor(nextColor);
			}
			resetChangeColor();
		}
		g2.setColor(c);
		if (c.getRGB() != Color.red.getRGB()) {
			System.out.print(c);
		}
		g2.fill(this);
		
	}


	public String toString() {
		return String.format("%s, %d, %d, %d, %d, %d%n", (fill ? "filledPlayer" : "player"), (int) x, (int) y,
				(int) width, (int) height, c.getRGB());
	}

	public void setChangeColor() {
		changeColor = true;
		
	}
	public void resetChangeColor() {
		changeColor = false;
	}
	public boolean checkChangeColor() {
		return changeColor;
	}
	public Color getColor() {
		return c;
	}
	public void setColor(Color newC) {
		c = newC;
	}

	public void setXY(int newX, int newY) {
		x = newX;
		y = newY;
	}
}
