package game;

import java.awt.Component;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.SwingUtilities;
import javax.swing.Timer;

import shapes.Ellipse;
import shapes.Player;


public class GameKeyListener implements KeyListener, ActionListener, ItemListener, MouseListener, MouseMotionListener {
	private Handler handler;
	private String command;
	private ArrayList<Shape> shapes;
	private Timer timer;
	private int speed;
	private int startTime;
	private int currentTime;
	private int finalTime;
	private Frame frame;
	private Player player;

	public GameKeyListener(Handler handler, Frame frame, Player player) {
		this.handler = handler;
		this.frame = frame;
		this.player = player;
		this.shapes = handler.getCurrentShapes();
		speed = 1000;
		startTime = 0;
		currentTime = 0;
		finalTime = 0;
		timer = new Timer(speed, this);
		timer.setInitialDelay(0);
		timer.start();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		shapes = handler.getCurrentShapes();
		if (shapes.size() > 0) {	
			currentTime = currentTime + 1;
			frame.setTime(currentTime);
		}
		if (shapes.size() == 0) {
			timer.stop();
			finalTime = currentTime;			
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		double x = e.getX();
		double y = e.getY();
		for (int i = 0; i < shapes.size(); i++) {
			Shape s = shapes.get(i);
			if (s.contains(x, y)) {
				if (((Ellipse) s).getDrawColor().getRGB() == player.getDrawColor().getRGB()) {
					((Ellipse) s).setToRemove();
				}
				
			}
		}
		if (SwingUtilities.isRightMouseButton(e)) {
			player.setChangeColor();
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public int getCurrentTime() {
		return currentTime;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		player.setXY((int) e.getX(),(int) e.getY());
	}

}