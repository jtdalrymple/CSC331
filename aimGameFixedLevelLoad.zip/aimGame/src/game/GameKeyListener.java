package game;
// NEWEST

import java.awt.Component;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.SwingUtilities;
import javax.swing.Timer;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JPanel;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;

import shapes.Ellipse;
import shapes.Player;

public class GameKeyListener implements KeyListener, ActionListener, ItemListener, MouseListener, MouseMotionListener {
	private Handler handler;
	private String command;
	private ArrayList<Shape> shapes;
	private Timer timer;
	private int speed;
	private int startTime;
	private int currentTime;
	private int finalTime;
	private Frame frame;
	private Player player;
	protected Clip coin, end;

	public GameKeyListener(Handler handler, Frame frame, Player player) {
		this.handler = handler;
		this.frame = frame;
		this.player = player;
		this.shapes = handler.getCurrentShapes();
		speed = 1000;
		startTime = 0;
		currentTime = 0;
		finalTime = 0;
		timer = new Timer(speed, this);
		timer.setInitialDelay(0);
		timer.start();

	}

	public Clip getAudioClip(String filename) {
		Clip clip = null;
		try {
			clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(new File(filename)));
		} catch (LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
			e1.printStackTrace();
		}

		return clip;
	}

	@Override
	public void keyPressed(KeyEvent e) {

	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void itemStateChanged(ItemEvent e) {

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		this.coin = getAudioClip("coin.aiff");
		this.end = getAudioClip("end.aiff");
		shapes = handler.getCurrentShapes();
		if (shapes.size() > 0) {
			currentTime = currentTime + 1;
			frame.setTime(currentTime);
			player.setChangeColor();
		}
		if (shapes.size() == 0) {
			end.setFramePosition(0);
			end.start();
			timer.stop();
			finalTime = currentTime;
			String text = Integer.toString(finalTime) + "\n";
			int n = handler.getLevel();
			try {
				Files.write(Paths.get("highscores" + n + ".txt"), text.getBytes(), StandardOpenOption.APPEND);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		double x = e.getX();
		double y = e.getY();
		for (int i = 0; i < shapes.size(); i++) {
			Shape s = shapes.get(i);
			if (s.contains(x, y)) {
				if (((Ellipse) s).getDrawColor().getRGB() == player.getDrawColor().getRGB()) {
					((Ellipse) s).setToRemove();
					coin.setFramePosition(0);
					coin.start();
				}

			}
		}
		if (SwingUtilities.isRightMouseButton(e)) {
			player.setChangeColor();
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public int getCurrentTime() {
		return currentTime;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {

	}
	
	public void resetTimer() {
		currentTime = 0;
		timer.restart();
	}
}