package shapes;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.util.ArrayList;

import shapes.Rectangle;
import game.Game;
import game.Handler;

public class Player extends Ellipse implements MoveableShape {

	private static final long serialVersionUID = -9086638501058842642L;
	private boolean changeColor;	
	private Handler handler;
	private double newX;
	private double newY;

	public Player(int x, int y, int w, int h, Color c, Handler handler) {
		super(x, y, w, h, c);
		this.handler = handler;
		changeColor = false;
	}

	public void tick() {
		
	}

	public void render(Graphics2D g2) {			
		g2.fill(this);
		
	}


	public String toString() {
		return String.format("%s, %d, %d, %d, %d, %d%n", (fill ? "filledPlayer" : "player"), (int) x, (int) y,
				(int) width, (int) height, c.getRGB());
	}

	public void setChangeColor() {
		changeColor = true;
		
	}
	public void resetChangeColor() {
		changeColor = false;
	}
	public boolean checkChangeColor() {
		return changeColor;
	}
	public Color getColor() {
		return c;
	}

	public void setXY(int setX, int setY) {
		newX = setX;
		newY = setY;
	}

	public void setColor(Color playerColor) {
		c = playerColor;
		
	}
}
