module aimGame {
	requires java.desktop;
}