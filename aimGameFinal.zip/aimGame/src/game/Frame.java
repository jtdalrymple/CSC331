package game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferStrategy;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

import shapes.Ellipse;
import shapes.Player;

public class Frame extends JFrame implements ActionListener, ItemListener {
	private static final long serialVersionUID = 2721843806653873180L;
	private JTextField timeDisplay, timeLabel;
	protected Clip music;
	private Handler handler;
	private Game game;

	public Frame(Game game, Handler handler, int w, int h) {
		super("Aim Trainer");
		this.handler = handler;
		setMaximumSize(new Dimension(w, h));
		setMinimumSize(new Dimension(w, h));
		setPreferredSize(new Dimension(w, h));
		setJMenuBar(createMenuBar());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		add(game);
		setVisible(true);
		timeLabel = new JTextField("Time: ");
		timeDisplay = new JTextField(Integer.toString(0), 10);
		JPanel pSouth = new JPanel();
		pSouth.add(timeLabel);
		pSouth.add(timeDisplay);
		add(pSouth, BorderLayout.WEST);
		pack();
		setResizable(false);
		setVisible(true);
		game.start();
		music.setFramePosition(0);
		music.start();
	}

	public Clip getAudioClip(String filename) {
		Clip clip = null;
		try {
			clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(new File(filename)));
		} catch (LineUnavailableException | IOException | UnsupportedAudioFileException e1) {
			e1.printStackTrace();
		}

		return clip;
	}

	public JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		JMenuItem menuItem;
		JMenu levelMenu = new JMenu("Levels");
		String[] commandslevels = { "Level 1", "Level 2", "Level 3", "Level 4" };
		for (int i = 0; i < commandslevels.length; i++) {
			menuItem = new JMenuItem(commandslevels[i]);
			menuItem.addActionListener(this);
			levelMenu.add(menuItem);
		}
		menuBar.add(levelMenu);
		JMenu scoreMenu = new JMenu("Highscores");
		String[] commandsedit = { "Highscores 1", "Highscores 2", "Highscores 3", "Highscores 4" };
		for (int i = 0; i < commandsedit.length; i++) {
			menuItem = new JMenuItem(commandsedit[i]);
			menuItem.addActionListener(this);
			scoreMenu.add(menuItem);
		}
		menuBar.add(scoreMenu);
		this.music = getAudioClip("music.aiff");
		return menuBar;
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub

	}

	public void setTime(int t) {
		timeDisplay.setText(Integer.toString(t));
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String command = e.getActionCommand();

		switch (command) {
		case "Level 1":
			handler.setLevel(1);
			handler.resetLevel(1);
			handler.resetTimer();
			break;

		case "Level 2":
			handler.loadHighscores(1);
			if (handler.getHighscores().size() > 0) {
				handler.setLevel(2);
				handler.resetLevel(2);
				handler.resetTimer();
			}
			break;

		case "Level 3":
			handler.loadHighscores(2);
			if (handler.getHighscores().size() > 0) {
				handler.setLevel(3);
				handler.resetLevel(3);
				handler.resetTimer();
			}
			break;
		
		case "Level 4":
			handler.loadHighscores(3);
			if (handler.getHighscores().size() > 0) {
				handler.setLevel(4);
				handler.resetLevel(4);
				handler.resetTimer();
			}
			break;

		case "Highscores 1":
			handler.loadHighscores(1);
			ArrayList<String> highscores1 = handler.getHighscores();
			String line1 = "";
			for (int i = 0; i < highscores1.size(); i++) {
				line1 = line1 + (i + 1) + ": " + highscores1.get(i) + "\n";
			}
			JOptionPane.showMessageDialog(null, line1);
			break;

		case "Highscores 2":
			handler.loadHighscores(2);
			ArrayList<String> highscores2 = handler.getHighscores();
			String line2 = "";
			for (int i = 0; i < highscores2.size(); i++) {
				line2 = line2 + (i + 1) + ": " + highscores2.get(i) + "\n";
			}
			JOptionPane.showMessageDialog(null, line2);
			break;

		case "Highscores 3":
			handler.loadHighscores(3);
			ArrayList<String> highscores3 = handler.getHighscores();
			String line3 = "";
			for (int i = 0; i < highscores3.size(); i++) {
				line3 = line3 + (i + 1) + ": " + highscores3.get(i) + "\n";
			}
			JOptionPane.showMessageDialog(null, line3);
			break;
		
		case "Highscores 4":
			handler.loadHighscores(4);
			ArrayList<String> highscores4 = handler.getHighscores();
			String line4 = "";
			for (int i = 0; i < highscores4.size(); i++) {
				line4 = line4 + (i + 1) + ": " + highscores4.get(i) + "\n";
			}
			JOptionPane.showMessageDialog(null, line4);
			break;
		}

	}

}
