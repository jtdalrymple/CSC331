package game;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

import javax.swing.JOptionPane;

import shapes.Ellipse;
import shapes.Player;
import shapes.Rectangle;

public class Handler {

	private ArrayList<Shape> shapesLevel0;
	private ArrayList<Shape> shapesLevel1;
	private ArrayList<Shape> shapesLevel2;
	private ArrayList<Shape> shapesLevel3;
	private ArrayList<Shape> shapesLevel4;
	private ArrayList<Shape> shapes;
	private int level;
	private Player player;
	private Color playerColor;
	private ArrayList<String> highscores;
	private GameKeyListener gameListener;
	private Boolean tutorial;

	public Handler() {
		shapesLevel0 = new ArrayList<Shape>();
		shapesLevel1 = new ArrayList<Shape>();
		shapesLevel2 = new ArrayList<Shape>();
		shapesLevel3 = new ArrayList<Shape>();
		shapesLevel4 = new ArrayList<Shape>();
		loadLevels();
		level = 0;
		shapes = getShapes(level);
		highscores = new ArrayList<String>();
		loadHighscores(1);
		tutorial = true;

	}

	public void tick() {
		Iterator<Shape> iterator = shapes.iterator();
		Shape si = null;
		while (iterator.hasNext()) {
			si = iterator.next();
			if (si instanceof Ellipse) {
				if (((Ellipse) si).checkToRemove() == true) {
					iterator.remove();
				}
			}

		}
	}

	public void render(Graphics2D g2) {

		for (int i = 0; i < shapes.size(); i++) {
			Shape s = shapes.get(i);

			if (s instanceof Ellipse) {
				Ellipse o = (Ellipse) s;
				g2.setColor(o.getDrawColor());
				if (o.isFill())
					g2.fill(o);
			}

			if (s instanceof Rectangle) {
				Rectangle o = (Rectangle) s;
				g2.setColor(o.getDrawColor());
				if (o.isFill())
					g2.fill(o);
			}

			g2.draw(s);

		}
		
		playerColor = player.getColor();
		if (player.checkChangeColor()) {
			if (player.getColor().getRGB() == Color.red.getRGB()) {
				playerColor = Color.yellow;
			}
			if (player.getColor().getRGB() == Color.yellow.getRGB()) {
				playerColor = Color.black;
			}
			if (player.getColor().getRGB() == Color.black.getRGB()) {
				playerColor = Color.red;
			}
			player.resetChangeColor();
		}
		player.setColor(playerColor);
		g2.setColor(playerColor);
		player.render(g2);
		if (tutorial) {
			JOptionPane.showMessageDialog(null, "Select a level from the top left menu. \n "
					+ "Each level must be cleared before the next is available. \n"
					+ "Click on the colored shapes when the circle in the top left of the screen matches to remove it. \n"
					+ "Once all shapes are removed, the stage is cleared. \n"
					+ "Right clicking will also change the color of the top left circle. \n"
					+ "Aim for the fastest time!");
		}
		tutorial = false;
	}

	public void addPlayer(Player player) {
		this.player = player;
	}

	public void addShape(Shape shape) {
		shapes.add(shape);
	}

	public void removeShape(Shape shape) {
		shapes.remove(shape);
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getLevel() {
		return level;
	}

	public void addLevelShape(ArrayList<Shape> level, Shape shape) {
		level.add(shape);
	}

	public ArrayList<Shape> getCurrentShapes() {
		return shapes;

	}

	public ArrayList<Shape> getShapes(int level) {
		switch (level) {
		case 0:
			return shapesLevel0;
		case 1:
			return shapesLevel1;
		case 2:
			return shapesLevel2;
		case 3:
			return shapesLevel3;
		case 4:
			return shapesLevel4;
		default:
			return shapesLevel1;
		}
	}

	void loadLevels() {
		Scanner sc = null;
		ArrayList<Shape> level;
		for (int i = 0; i < 5; i++) {
			level = getShapes(i);
			try {
				sc = new Scanner(new File("levels/level" + i + ".txt"));
				while (sc.hasNextLine()) {
					String line = sc.nextLine().trim();
					if (line.startsWith("filledCircle") || line.startsWith("circle"))
						addLevelShape(level, new Ellipse(line));
					if (line.startsWith("filledRectangle") || line.startsWith("circle"))
						addLevelShape(level, new Rectangle(line));
				}
				sc.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	void loadHighscores(int i) {
		if (highscores != null) {
			deleteHighscores();
		}
		Scanner sc = null;
		try {
			sc = new Scanner(new File("highscores" + i + ".txt"));
			while (sc.hasNextLine()) {
				String line = sc.nextLine().trim();
				highscores.add(line);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void deleteHighscores() {
		highscores.clear();

	}

	ArrayList<String> getHighscores() {
		return highscores;
	}

	public void addGameListener(GameKeyListener gameListener) {
		this.gameListener = gameListener;

	}

	public void resetTimer() {
		gameListener.resetTimer();
	}

	public void resetLevel(int i) {
		loadLevels();
		shapes = getShapes(i);
	}
}
