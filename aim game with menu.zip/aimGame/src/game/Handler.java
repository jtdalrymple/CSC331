package game;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

import shapes.Ellipse;

public class Handler {

	private ArrayList<Shape> shapesLevel1;
	private ArrayList<Shape> shapesLevel2;
	private ArrayList<Shape> shapesLevel3;
	private ArrayList<Shape> shapesLevel4;
	private ArrayList<Shape> shapes;
	private int level;

	public Handler() {
		shapesLevel1 = new ArrayList<Shape>();
		shapesLevel2 = new ArrayList<Shape>();
		shapesLevel3 = new ArrayList<Shape>();
		shapesLevel4 = new ArrayList<Shape>();
		loadLevels();
		level = 4;
		shapes = getShapes(level);
	}

	public void tick() {
		Iterator<Shape> iterator = shapes.iterator();
		Shape si = null;
		while (iterator.hasNext()) {
			si = iterator.next();
			if (si instanceof Ellipse) {
				if (((Ellipse) si).checkToRemove() == true) {
					iterator.remove();
				}
			}

		}
		if (shapes.size() == 0) {
			// Stop timer, save time to highscore file and if time is less than threshold
			// and mark as beaten
		}
	}

	public void render(Graphics2D g2) {

		for (int i = 0; i < shapes.size(); i++) {
			Shape s = shapes.get(i);

			if (s instanceof Ellipse) {
				Ellipse o = (Ellipse) s;
				g2.setColor(o.getDrawColor());
				if (o.isFill())
					g2.fill(o);
			}

			g2.draw(s);
		}
	}

	public void addShape(Shape shape) {
		shapes.add(shape);
	}

	public void removeShape(Shape shape) {
		shapes.remove(shape);
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getLevel() {
		return level;
	}

	public void addLevelShape(ArrayList<Shape> level, Shape shape) {
		level.add(shape);
	}

	public ArrayList<Shape> getCurrentShapes() {
		return shapes;

	}

	public ArrayList<Shape> getShapes(int level) {
		switch (level) {
		case 1:
			return shapesLevel1;
		case 2:
			return shapesLevel2;
		case 3:
			return shapesLevel3;
		case 4:
			return shapesLevel4;
		default:
			return shapesLevel1;
		}
	}

	private void loadLevels() {
		Scanner sc = null;
		ArrayList<Shape> level;
		for (int i = 1; i < 5; i++) {
			level = getShapes(i);
			try {
				sc = new Scanner(new File("levels/level" + i + ".txt"));
				while (sc.hasNextLine()) {
					String line = sc.nextLine().trim();
					if (line.startsWith("filledCircle") || line.startsWith("circle"))
						addLevelShape(level, new Ellipse(line));
				}
				sc.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

}
